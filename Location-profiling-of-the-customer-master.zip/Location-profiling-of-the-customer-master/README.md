# Location-profiling-of-the-customer
Learnt and applied clustering algorithm in Python on real time GPS pings from App data . Analysed Geo-location footprints to identify Home Location, Office location using density based clustering . Created key indicators like home-office distance, behavioural information to be used in Credit application model
